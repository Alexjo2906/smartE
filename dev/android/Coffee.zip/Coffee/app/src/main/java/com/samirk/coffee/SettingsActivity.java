package com.samirk.coffee;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.samirk.coffee.data.PreferenceUtils;
import com.samirk.coffee.data.ServerModel;
import com.samirk.coffee.data.UserModel;
import com.samirk.coffee.data.Utils;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {


    public static final String EXTRA_SERVER_1 = "SERVER_1";
    public static final String EXTRA_SERVER_2 = "SERVER_2";
    public static final String EXTRA_SERVER_3 = "SERVER_3";

    SeekBar mSbSugar, mSbCoffee, mSbWater;
    Spinner mSpinnerType;
    Button mBtnUpdate;

    UserModel mUserModel;
    ServerModel mServer1, mServer2, mServer3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        if (getIntent().getExtras() != null) {
            mUserModel = (UserModel) getIntent().getExtras().getSerializable(DashboardActivity.EXTRA_USER);
            mServer1 = (ServerModel) getIntent().getExtras().getSerializable(EXTRA_SERVER_1);
            mServer2 = (ServerModel) getIntent().getExtras().getSerializable(EXTRA_SERVER_2);
            mServer3 = (ServerModel) getIntent().getExtras().getSerializable(EXTRA_SERVER_3);
        }


        mSbCoffee = findViewById(R.id.sb_coffee);
        mSbWater = findViewById(R.id.sb_water);
        mSbSugar = findViewById(R.id.sb_sugar);

        getServer1();

        mBtnUpdate = findViewById(R.id.btn_update);

        mSpinnerType = findViewById(R.id.spinner_type);
        mSpinnerType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                 /*   case 0:
                        mBtnUpdate.setText("Update");
                        mSbCoffee.setProgress(mUserModel.getCoffee());
                        mSbSugar.setProgress(mUserModel.getSugar());
                        mSbWater.setProgress(mUserModel.getWater());

                        break;*/
                    case 0:
                        mBtnUpdate.setText("Update (Server 1)");
                        mSbCoffee.setProgress(0);
                        mSbSugar.setProgress(0);
                        mSbWater.setProgress(0);

                        getServer1();
                        break;
                    case 1:
                        mBtnUpdate.setText("Update (Server 2)");
                        mSbCoffee.setProgress(0);
                        mSbSugar.setProgress(0);
                        mSbWater.setProgress(0);

                        getServer2();
                        break;
                    case 2:
                        mBtnUpdate.setText("Update (Server 3)");
                        mSbCoffee.setProgress(0);
                        mSbSugar.setProgress(0);
                        mSbWater.setProgress(0);

                        getServer3();
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }


    public void update(View view) {


        int pos = mSpinnerType.getSelectedItemPosition();

        if (pos == 2) {
            updateServer3();
            return;
        } else if (pos == 1) {
            updateServer2();
            return;
        } else if (pos == 0) {
            updateServer1();
            return;
        }


       /* Utils.getUserDatabase()
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        DatabaseReference reference = null;

                        for (DataSnapshot user : dataSnapshot.getChildren()) {

                            if (user.child("email").getValue(String.class)
                                    .equals(mUserModel.getEmail())) {
                                reference = user.getRef();
                                break;
                            }
                        }

                        if (reference != null) {
                            reference.child("coffee").setValue(mSbCoffee.getProgress());
                            reference.child("water").setValue(mSbWater.getProgress());
                            reference.child("sugar").setValue(mSbSugar.getProgress());

                            mUserModel.setSugar(mSbSugar.getProgress());
                            mUserModel.setWater(mSbWater.getProgress());
                            mUserModel.setCoffee(mSbCoffee.getProgress());
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(SettingsActivity.this,
                                "Error occurs", Toast.LENGTH_SHORT).show();
                    }
                });
*/
    }


    public void getServer1() {

        PreferenceUtils utils = new PreferenceUtils(this);

        final String username = utils.getUsername();
        final String password = utils.getPassword();

        Utils.getUserDatabase()
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                        for (DataSnapshot user : dataSnapshot.getChildren()) {

                            if (user.child("email").getValue(String.class).equals(username)
                                    && user.child("password").getValue(String.class).equals(password)) {

                                DatabaseReference reference = dataSnapshot.getRef();


                                if (reference != null) {
                                    mSbCoffee.setProgress(user.child("servers").child("0").child("coffee").getValue(Integer.class));
                                    mSbWater.setProgress(user.child("servers").child("0").child("water").getValue(Integer.class));
                                    mSbSugar.setProgress(user.child("servers").child("0").child("sugar").getValue(Integer.class));

                                }
                            }
                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(SettingsActivity.this,
                                "Error occurs", Toast.LENGTH_SHORT).show();
                    }
                });

    }


    public void getServer2() {


        PreferenceUtils utils = new PreferenceUtils(this);

        final String username = utils.getUsername();
        final String password = utils.getPassword();

        Utils.getUserDatabase()
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                        for (DataSnapshot user : dataSnapshot.getChildren()) {

                            if (user.child("email").getValue(String.class).equals(username)
                                    && user.child("password").getValue(String.class).equals(password)) {

                                DatabaseReference reference = dataSnapshot.getRef();


                                if (reference != null) {
                                    mSbCoffee.setProgress(user.child("servers").child("1").child("coffee").getValue(Integer.class));
                                    mSbWater.setProgress(user.child("servers").child("1").child("water").getValue(Integer.class));
                                    mSbSugar.setProgress(user.child("servers").child("1").child("sugar").getValue(Integer.class));

                                }
                            }
                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(SettingsActivity.this,
                                "Error occurs", Toast.LENGTH_SHORT).show();
                    }
                });

    }


    public void getServer3() {


        PreferenceUtils utils = new PreferenceUtils(this);

        final String username = utils.getUsername();
        final String password = utils.getPassword();

        Utils.getUserDatabase()
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                        for (DataSnapshot user : dataSnapshot.getChildren()) {

                            if (user.child("email").getValue(String.class).equals(username)
                                    && user.child("password").getValue(String.class).equals(password)) {

                                DatabaseReference reference = dataSnapshot.getRef();


                                if (reference != null) {
                                    mSbCoffee.setProgress(user.child("servers").child("2").child("coffee").getValue(Integer.class));
                                    mSbWater.setProgress(user.child("servers").child("2").child("water").getValue(Integer.class));
                                    mSbSugar.setProgress(user.child("servers").child("2").child("sugar").getValue(Integer.class));

                                }
                            }
                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(SettingsActivity.this,
                                "Error occurs", Toast.LENGTH_SHORT).show();
                    }
                });

    }

    public void updateServer1() {


        PreferenceUtils utils = new PreferenceUtils(this);

        final String username = utils.getUsername();
        final String password = utils.getPassword();

        Utils.getUserDatabase()
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                        for (DataSnapshot user : dataSnapshot.getChildren()) {

                            if (user.child("email").getValue(String.class).equals(username)
                                    && user.child("password").getValue(String.class).equals(password)) {

                                DatabaseReference reference = user.getRef();


                                if (reference != null) {
                                    reference.child("servers").child("0").child("coffee").setValue(mSbCoffee.getProgress());
                                    reference.child("servers").child("0").child("water").setValue(mSbWater.getProgress());
                                    reference.child("servers").child("0").child("sugar").setValue(mSbSugar.getProgress());

                                    Toast.makeText(SettingsActivity.this,
                                            "Data Updated", Toast.LENGTH_SHORT).show();

                                }
                            }
                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(SettingsActivity.this,
                                "Error occurs", Toast.LENGTH_SHORT).show();
                    }
                });

    }

    public void updateServer2() {
        PreferenceUtils utils = new PreferenceUtils(this);

        final String username = utils.getUsername();
        final String password = utils.getPassword();

        Utils.getUserDatabase()
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                        for (DataSnapshot user : dataSnapshot.getChildren()) {

                            if (user.child("email").getValue(String.class).equals(username)
                                    && user.child("password").getValue(String.class).equals(password)) {

                                DatabaseReference reference = user.getRef();


                                if (reference != null) {
                                    reference.child("servers").child("1").child("coffee").setValue(mSbCoffee.getProgress());
                                    reference.child("servers").child("1").child("water").setValue(mSbWater.getProgress());
                                    reference.child("servers").child("1").child("sugar").setValue(mSbSugar.getProgress());

                                    Toast.makeText(SettingsActivity.this,
                                            "Data Updated", Toast.LENGTH_SHORT).show();

                                }
                            }
                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(SettingsActivity.this,
                                "Error occurs", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    public void updateServer3() {
        PreferenceUtils utils = new PreferenceUtils(this);

        final String username = utils.getUsername();
        final String password = utils.getPassword();

        Utils.getUserDatabase()
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                        for (DataSnapshot user : dataSnapshot.getChildren()) {

                            if (user.child("email").getValue(String.class).equals(username)
                                    && user.child("password").getValue(String.class).equals(password)) {

                                DatabaseReference reference = user.getRef();


                                if (reference != null) {
                                    reference.child("servers").child("2").child("coffee").setValue(mSbCoffee.getProgress());
                                    reference.child("servers").child("2").child("water").setValue(mSbWater.getProgress());
                                    reference.child("servers").child("2").child("sugar").setValue(mSbSugar.getProgress());

                                    Toast.makeText(SettingsActivity.this,
                                            "Data Updated", Toast.LENGTH_SHORT).show();

                                }
                            }
                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(SettingsActivity.this,
                                "Error occurs", Toast.LENGTH_SHORT).show();
                    }
                });

    }
}
