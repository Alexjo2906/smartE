package com.samirk.coffee;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.samirk.coffee.data.UserModel;
import com.samirk.coffee.data.Utils;

public class WaitingActivity extends AppCompatActivity {

    public static final String EXTRA_SERVER = "SERVER";
    public static final String EXTRA_USER = "USER";

    String server = "server1";

    UserModel userModel;
    ImageView imgC1, imgC2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_waiting);


        server = getIntent().getStringExtra(EXTRA_SERVER);
        userModel = (UserModel) getIntent().getExtras().getSerializable(EXTRA_USER);


        imgC1 = findViewById(R.id.imgCircle1);
        imgC2 = findViewById(R.id.imgCircle2);

        getServer();
        getCircles();
    }

    public void ready() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Finished");
        builder.setMessage("Your coffee is ready...");
        builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                updateServer();
                finish();
            }
        });

        try {
            builder.show();
        } catch (Exception e) {

        }
    }


    public void getCircles() {


        Utils.getCircleDatabase()
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                        int c1 = dataSnapshot.child("circle1").getValue(Integer.class);
                        int c2 = dataSnapshot.child("circle2").getValue(Integer.class);

                        if (c1 == 1)
                            imgC1.setImageDrawable(getResources().getDrawable(R.drawable.ic_circle_blue));
                        else if (c1 == 2)
                            imgC1.setImageDrawable(getResources().getDrawable(R.drawable.ic_circle_red));
                        else
                            imgC1.setImageDrawable(getResources().getDrawable(R.drawable.ic_circle_gray));

                        if (c2 == 1)
                            imgC2.setImageDrawable(getResources().getDrawable(R.drawable.ic_circle_blue));
                        else if (c2 == 2)
                            imgC2.setImageDrawable(getResources().getDrawable(R.drawable.ic_circle_red));
                        else
                            imgC2.setImageDrawable(getResources().getDrawable(R.drawable.ic_circle_gray));


                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(WaitingActivity.this,
                                "Error occurs", Toast.LENGTH_SHORT).show();
                    }
                });

    }


    public void getServer() {


        if (server == null)
            return;

        Utils.getUserDatabase()
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        for (DataSnapshot user : dataSnapshot.getChildren()) {

                            if (user.child("email").getValue(String.class).equals(userModel.getEmail())
                                    && user.child("password").getValue(String.class).equals(userModel.getPassword())) {

                                boolean isReady = user.
                                        child("servers").child(server)
                                        .child("status").getValue(Boolean.class);

                                if (isReady)
                                    ready();
                            }
                        }


                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(WaitingActivity.this,
                                "Error occurs", Toast.LENGTH_SHORT).show();
                    }
                });

    }

    public void updateServer() {

        if (server == null)
            return;

        Utils.getUserDatabase()
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                        for (DataSnapshot user : dataSnapshot.getChildren()) {

                            if (user.child("email").getValue(String.class).equals(userModel.getEmail())
                                    && user.child("password").getValue(String.class).equals(userModel.getPassword())) {
                                user.child("servers").child(server)
                                        .getRef().child("status").setValue(false);
                            }
                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(WaitingActivity.this,
                                "Error occurs", Toast.LENGTH_SHORT).show();
                    }
                });

    }
}
