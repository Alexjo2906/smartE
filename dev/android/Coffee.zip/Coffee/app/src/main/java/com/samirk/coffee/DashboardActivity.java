package com.samirk.coffee;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.samirk.coffee.data.PreferenceUtils;
import com.samirk.coffee.data.ServerModel;
import com.samirk.coffee.data.UserModel;
import com.samirk.coffee.data.Utils;

public class DashboardActivity extends AppCompatActivity {

    public static final String EXTRA_USER = "USER";

    ImageView mImgServer1, mImgServer2, mImgServer3;
    TextView mTvServer1, mTvServer2, mTvServer3;

    ProgressBar mPbCoffee, mPbWater, mPbSugar;

    UserModel mUserModel;
    ServerModel mServer1, mServer2, mServer3;

    String server = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        if (getIntent().getExtras() != null)
            mUserModel = (UserModel) getIntent().getExtras().getSerializable(EXTRA_USER);

        if (mUserModel == null) {
            login();
        }

        mImgServer1 = findViewById(R.id.img_server_1);
        mImgServer2 = findViewById(R.id.img_server_2);
        mImgServer3 = findViewById(R.id.img_server_3);
        mTvServer1 = findViewById(R.id.tv_server_1);
        mTvServer2 = findViewById(R.id.tv_server_2);
        mTvServer3 = findViewById(R.id.tv_server_3);

        mPbCoffee = findViewById(R.id.progress_coffee);
        mPbWater = findViewById(R.id.progress_water);
        mPbSugar = findViewById(R.id.progress_sugar);

        loadIngredients();
        loadServers();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_dashboard, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == R.id.menu_settings) {

            Bundle bundle = new Bundle();
            bundle.putSerializable(DashboardActivity.EXTRA_USER, mUserModel);
            bundle.putSerializable(SettingsActivity.EXTRA_SERVER_1, mServer1);
            bundle.putSerializable(SettingsActivity.EXTRA_SERVER_3, mServer2);
            bundle.putSerializable(SettingsActivity.EXTRA_SERVER_3, mServer3);

            Intent intent = new Intent(this, SettingsActivity.class);
            intent.putExtras(bundle);


            startActivity(intent);

        } else if (item.getItemId() == R.id.menu_logout) {
            logout();
        }

        return super.onOptionsItemSelected(item);
    }


    public void updateUi(int value) {
        switch (value) {
            case -1:
                mImgServer1.setImageDrawable(getResources().getDrawable(R.drawable.ic_coffee));
                mImgServer2.setImageDrawable(getResources().getDrawable(R.drawable.ic_coffee));
                mImgServer3.setImageDrawable(getResources().getDrawable(R.drawable.ic_coffee));

                mTvServer1.setTextColor(getResources().getColor(android.R.color.darker_gray));
                mTvServer2.setTextColor(getResources().getColor(android.R.color.darker_gray));
                mTvServer3.setTextColor(getResources().getColor(android.R.color.darker_gray));

                server = "";
                break;
            case 1:
                mImgServer1.setImageDrawable(getResources().getDrawable(R.drawable.ic_coffee_selected));
                mImgServer2.setImageDrawable(getResources().getDrawable(R.drawable.ic_coffee));
                mImgServer3.setImageDrawable(getResources().getDrawable(R.drawable.ic_coffee));

                mTvServer1.setTextColor(getResources().getColor(R.color.colorPrimaryDark));
                mTvServer2.setTextColor(getResources().getColor(android.R.color.darker_gray));
                mTvServer3.setTextColor(getResources().getColor(android.R.color.darker_gray));

                server = "server1";
                break;
            case 2:
                mImgServer1.setImageDrawable(getResources().getDrawable(R.drawable.ic_coffee));
                mImgServer2.setImageDrawable(getResources().getDrawable(R.drawable.ic_coffee_selected));
                mImgServer3.setImageDrawable(getResources().getDrawable(R.drawable.ic_coffee));

                mTvServer1.setTextColor(getResources().getColor(android.R.color.darker_gray));
                mTvServer2.setTextColor(getResources().getColor(R.color.colorPrimaryDark));
                mTvServer3.setTextColor(getResources().getColor(android.R.color.darker_gray));

                server = "server2";
                break;
            case 3:
                mImgServer1.setImageDrawable(getResources().getDrawable(R.drawable.ic_coffee));
                mImgServer2.setImageDrawable(getResources().getDrawable(R.drawable.ic_coffee));
                mImgServer3.setImageDrawable(getResources().getDrawable(R.drawable.ic_coffee_selected));

                mTvServer1.setTextColor(getResources().getColor(android.R.color.darker_gray));
                mTvServer2.setTextColor(getResources().getColor(android.R.color.darker_gray));
                mTvServer3.setTextColor(getResources().getColor(R.color.colorPrimaryDark));

                server = "server3";
                break;
        }
    }


    public void login() {

        final PreferenceUtils utils = new PreferenceUtils(DashboardActivity.this);
        final String password = utils.getPassword();
        final String username = utils.getUsername();

        Utils.getUserDatabase()
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        boolean isAuthorized = false;

                        for (DataSnapshot user : dataSnapshot.getChildren()) {

                            if (user.child("email").getValue(String.class).equals(username)
                                    && user.child("password").getValue(String.class).equals(password)) {

                                mUserModel = new UserModel();
                                mUserModel.setPassword(password);
                                mUserModel.setEmail(username);
                                mUserModel.setId(user.child("id").getValue(Integer.class));
                                mUserModel.setWater(user.child("water").getValue(Integer.class));
                                mUserModel.setCoffee(user.child("coffee").getValue(Integer.class));
                                mUserModel.setSugar(user.child("sugar").getValue(Integer.class));
                                isAuthorized = true;
                            }

                        }

                        if (!isAuthorized) {
                            utils.setLogin(false);
                            utils.setPassword("");
                            utils.setUsername("");
                            Toast.makeText(DashboardActivity.this, "Sessions timeout, please login again", Toast.LENGTH_SHORT).show();

                        } else {

                            PreferenceUtils utils = new PreferenceUtils(DashboardActivity.this);
                            utils.setPassword(password);
                            utils.setUsername(username);
                            utils.setLogin(true);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(DashboardActivity.this,
                                "Error occurs", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    public void logout() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirmation");
        builder.setMessage("Do you want to continue logging out?");
        builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                PreferenceUtils utils = new PreferenceUtils(DashboardActivity.this);
                utils.setUsername("");
                utils.setPassword("");
                utils.setLogin(false);

                Toast.makeText(DashboardActivity.this, "Successfully logged out",
                        Toast.LENGTH_SHORT).show();
                finish();
            }
        });
        builder.show();
    }

    public void startWaiting(View view) {

        int id = view.getId();

        if (id == R.id.layout_service_1)
            server = "0";
        else if (id == R.id.layout_service_2)
            server = "1";
        else if (id == R.id.layout_service_3)
            server = "2";

        Intent intent = new Intent(this, WaitingActivity.class);
        intent.putExtra(WaitingActivity.EXTRA_SERVER, server);

        Bundle bundle = new Bundle();
        bundle.putSerializable(WaitingActivity.EXTRA_USER, mUserModel);
        intent.putExtras(bundle);
        startActivity(intent);
    }


    public void loadIngredients() {

        Utils.getStorageDatabase()
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        mPbCoffee.setProgress(dataSnapshot.child("coffee").getValue(Integer.class));
                        mPbWater.setProgress(dataSnapshot.child("water").getValue(Integer.class));
                        mPbSugar.setProgress(dataSnapshot.child("sugar").getValue(Integer.class));

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                    }
                });
    }


    public void loadServers() {

        final PreferenceUtils utils = new PreferenceUtils(DashboardActivity.this);
        final String password = utils.getPassword();
        final String username = utils.getUsername();

        Utils.getUserDatabase()
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                        for (DataSnapshot user : dataSnapshot.getChildren()) {

                            if (user.child("email").getValue(String.class).equals(username)
                                    && user.child("password").getValue(String.class).equals(password)) {

                                mServer1 = user.child("servers").child("0").getValue(ServerModel.class);
                                mServer2 = user.child("servers").child("1").getValue(ServerModel.class);
                                mServer3 = user.child("servers").child("2").getValue(ServerModel.class);

                                if (mServer1.isStatus())
                                    updateUi(1);
                                else if (mServer2.isStatus())
                                    updateUi(2);
                                else if (mServer3.isStatus())
                                    updateUi(3);
                                else
                                    updateUi(-1);

                            }

                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(DashboardActivity.this,
                                "Error occurs", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
