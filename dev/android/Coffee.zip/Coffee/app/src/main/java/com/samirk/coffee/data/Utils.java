package com.samirk.coffee.data;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Utils {

    private static final String NODE_ROOT = "data";
    private static final String NODE_USERS = "users";
    private static final String NODE_INGREDIENTS_STORAGE = "ingredients_storage";
    private static final String NODE_SERVERS = "servers";
    private static final String NODE_CIRCLES = "circles";

    private static DatabaseReference mDatabaseReference;

    public static DatabaseReference getUserDatabase() {
        return getDefaultNode().child(NODE_USERS);
    }


    public static DatabaseReference getStorageDatabase() {
        return getDefaultNode().child(NODE_INGREDIENTS_STORAGE);
    }

    public static DatabaseReference getServerDatabase() {
        return getDefaultNode().child(NODE_SERVERS);
    }
    public static DatabaseReference getCircleDatabase() {
        return getDefaultNode().child(NODE_CIRCLES);
    }


    private static DatabaseReference getDefaultNode() {
        if (mDatabaseReference == null)
            mDatabaseReference = FirebaseDatabase.getInstance().getReference(NODE_ROOT);

        return mDatabaseReference;
    }
}
