package com.samirk.coffee;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.samirk.coffee.data.PreferenceUtils;
import com.samirk.coffee.data.UserModel;
import com.samirk.coffee.data.Utils;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Toast;

import java.util.Arrays;

public class RegisterActivity extends AppCompatActivity {


    private EditText mEtEmail, mEtPassword, mEtConfirmPassword;
    private SeekBar mSbCoffee, mSbWater, mSbSugar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mEtEmail = findViewById(R.id.et_email);
        mEtPassword = findViewById(R.id.et_password);
        mEtConfirmPassword = findViewById(R.id.et_password_confirm);
        mSbCoffee = findViewById(R.id.sb_coffee);
        mSbWater = findViewById(R.id.sb_water);
        mSbSugar = findViewById(R.id.sb_sugar);

    }

    public void register(View view) {

        UserModel userModel = new UserModel();
        userModel.setEmail(mEtEmail.getText().toString());
        userModel.setPassword(mEtPassword.getText().toString());
        userModel.setCoffee(mSbCoffee.getProgress());
        userModel.setSugar(mSbSugar.getProgress());
        userModel.setWater(mSbWater.getProgress());


        if (!isDataValid(userModel, mEtConfirmPassword.getText().toString()))
            return;

        confirmEmail(userModel);
    }

    public boolean isDataValid(UserModel userModel, String confirmPassword) {

        if (TextUtils.isEmpty(userModel.getEmail())
                || TextUtils.isEmpty(userModel.getPassword())) {

            Toast.makeText(this, "Invalid data please", Toast.LENGTH_SHORT).show();
            return false;

        }

        if (!userModel.getPassword().equals(confirmPassword)) {

            Toast.makeText(this, "Password doesn't match", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }


    public void addUser(final UserModel userModel) {


        Utils.getUserDatabase()
                .push()
                .setValue(userModel)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {

                        Toast.makeText(RegisterActivity.this, "User has been registered successfully", Toast.LENGTH_SHORT).show();

                        PreferenceUtils utils = new PreferenceUtils(RegisterActivity.this);
                        utils.setPassword(userModel.getPassword());
                        utils.setUsername(userModel.getEmail());
                        utils.setLogin(true);

                        Bundle bundle = new Bundle();
                        bundle.putSerializable(DashboardActivity.EXTRA_USER, userModel);

                        Intent intent = new Intent(RegisterActivity.this, DashboardActivity.class);
                        intent.putExtras(bundle);

                        startActivity(intent);
                        finish();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                        Toast.makeText(RegisterActivity.this, "Error while registering user "
                                + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    public void confirmEmail(final UserModel userModel) {
        Utils.getUserDatabase()
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        int id = 0;
                        boolean isValid = true;

                        for (DataSnapshot user : dataSnapshot.getChildren()) {


                            if (id <= user.child("id").getValue(Long.class))
                                id++;

                            if (user.child("email").getValue(String.class).equals(userModel.getEmail()))
                                isValid = false;

                        }

                        if (!isValid)
                            Toast.makeText(RegisterActivity.this, "Email already exists", Toast.LENGTH_SHORT).show();
                        else {
                            userModel.setId(id);
                            addUser(userModel);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(RegisterActivity.this,
                                "Error occurs", Toast.LENGTH_SHORT).show();
                    }
                });
    }

}
