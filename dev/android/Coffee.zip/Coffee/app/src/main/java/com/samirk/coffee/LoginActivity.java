package com.samirk.coffee;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.samirk.coffee.data.PreferenceUtils;
import com.samirk.coffee.data.UserModel;
import com.samirk.coffee.data.Utils;

public class LoginActivity extends AppCompatActivity {

    private EditText mEtEmail, mEtPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mEtEmail = findViewById(R.id.et_email);
        mEtPassword = findViewById(R.id.et_password);

    }

    public void login(View view) {

        UserModel userModel = new UserModel();
        userModel.setEmail(mEtEmail.getText().toString());
        userModel.setPassword(mEtPassword.getText().toString());

        login(userModel);


    }

    public void login(final UserModel userModel) {

        Utils.getUserDatabase()
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        boolean isAuthorized = false;

                        for (DataSnapshot user : dataSnapshot.getChildren()) {

                            if (user.child("email").getValue(String.class).equals(userModel.getEmail())
                                    && user.child("password").getValue(String.class).equals(userModel.getPassword())) {
                                isAuthorized = true;
                            }

                        }

                        if (!isAuthorized)
                            Toast.makeText(LoginActivity.this, "User doesn't exist", Toast.LENGTH_SHORT).show();
                        else {

                            PreferenceUtils utils = new PreferenceUtils(LoginActivity.this);
                            utils.setPassword(userModel.getPassword());
                            utils.setUsername(userModel.getEmail());
                            utils.setLogin(true);

                            Bundle bundle = new Bundle();
                            bundle.putSerializable(DashboardActivity.EXTRA_USER, userModel);

                            Intent intent = new Intent(LoginActivity.this, DashboardActivity.class);
                            intent.putExtras(bundle);

                            startActivity(intent);
                            finish();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(LoginActivity.this,
                                "Error occurs", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
