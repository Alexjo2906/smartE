package com.samirk.coffee.data;

import android.content.Context;
import android.content.SharedPreferences;

public class PreferenceUtils {
    private static final String PREF_IS_LOGIN = "IS_USER_LOGIN";
    private static final String PREF_PASSWORD = "PASSWORD";
    private static final String PREF_USERNAME = "USERNAME";
    private static final String PREF_HASH = "HASH";

    SharedPreferences mSharedPreferences;
    SharedPreferences.Editor mEditor;

    public PreferenceUtils(Context context) {
        mSharedPreferences = context.getSharedPreferences("com.samirk.coffee.file",
                Context.MODE_PRIVATE);

        mEditor = mSharedPreferences.edit();
    }

    public boolean isLogin() {
        return mSharedPreferences.getBoolean(PREF_IS_LOGIN, false);
    }

    public void setLogin(boolean isLogin) {
        mEditor.putBoolean(PREF_IS_LOGIN, isLogin);
        mEditor.commit();
    }

    public String getPassword() {
        return mSharedPreferences.getString(PREF_PASSWORD, "");
    }

    public void setPassword(String password) {
        mEditor.putString(PREF_PASSWORD, password);
        mEditor.commit();
    }

    public String getUsername() {
        return mSharedPreferences.getString(PREF_USERNAME, "");
    }

    public void setUsername(String password) {
        mEditor.putString(PREF_USERNAME, password);
        mEditor.commit();
    }

    public String getHash() {
        return mSharedPreferences.getString(PREF_HASH, "");
    }

    public void setHash(String hash) {
        mEditor.putString(PREF_HASH, hash);
        mEditor.commit();
    }

}
