package com.samirk.coffee.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class UserModel implements Serializable {

    String email, password;
    int id, sugar, coffee, water;

    List<ServerModel> servers = new ArrayList<>();

    public UserModel() {
        ServerModel server1 = new ServerModel();
        ServerModel server2 = new ServerModel();
        ServerModel server3 = new ServerModel();

        servers.add(server1);
        servers.add(server2);
        servers.add(server3);
    }


    public List<ServerModel> getServers() {
        return servers;
    }

    public void setServers(List<ServerModel> servers) {
        this.servers = servers;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getSugar() {
        return sugar;
    }

    public void setSugar(int sugar) {
        this.sugar = sugar;
    }

    public int getCoffee() {
        return coffee;
    }

    public void setCoffee(int coffee) {
        this.coffee = coffee;
    }

    public int getWater() {
        return water;
    }

    public void setWater(int water) {
        this.water = water;
    }
}
